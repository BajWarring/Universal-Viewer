# Android permissions needed in AndroidManifest.xml:
# <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
# <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />
# <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />
# 
# Also add inside <application> tag:
# android:requestLegacyExternalStorage="true"
